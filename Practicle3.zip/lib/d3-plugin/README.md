# d3-foo

YOUR DESCRIPTION HERE. Replace all instances of `foo` in this file with the name of your new plugin.

## Installing

If you use NPM, `npm install d3-foo`. Otherwise, download the [latest release](https://github.com/d3/d3-foo/releases/latest).

## API Reference

YOUR API DOCUMENTATION HERE. Use bold for symbols (such as constructor and method names) and italics for instances. See the other D3 modules for examples.

<a href="#foo" name="foo">#</a> <b>foo</b>()

Computes the answer to the ultimate question of life, the universe, and everything.
